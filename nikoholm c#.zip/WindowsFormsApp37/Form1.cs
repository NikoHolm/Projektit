﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace WindowsFormsApp37
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {
            richtxtbox.Clear(); //tehdään reset että kaikki teksti lähtee kun nappia painaa richtxtboxista

            double Pepperoni, hawai, jauhenliha, lihamestari, texas, kasvis, vege, kebabsalami, kanabbq, kebabmajoneesi; //määritellään pizzoille nimet
            double kertoja1, kertoja2, kertoja3;
            double kertoja4, kertoja5, kertoja6, kertoja7, kertoja8, kertoja9, kertoja10;//määritellään kertojat joilla kerrotaan että saadaan pizzojen määrä kerrottuna lukuun
            double juoma1, juoma2; // määritellään juomat
            double kertoja11, kertoja12;
            double tulos;
            Pepperoni = 0; //määritellään pizzoille hinnat
            hawai = 0;
            jauhenliha = 0;
            lihamestari = 0;
            texas = 0;
            kasvis = 0;
            vege = 0;
            kebabsalami = 0;
            kanabbq = 0;
            kebabmajoneesi = 0;
            juoma1 = 0;
            juoma2 = 0;

            kertoja1 = double.Parse(textBox1.Text); //kerrotaan kertomien sijainnit
            kertoja2 = double.Parse(textBox2.Text);
            kertoja3 = double.Parse(textBox3.Text);
            kertoja4 = double.Parse(textBox4.Text);
            kertoja5 = double.Parse(textBox5.Text);
            kertoja6 = double.Parse(textBox6.Text);
            kertoja7 = double.Parse(textBox7.Text);
            kertoja8 = double.Parse(textBox8.Text);
            kertoja9 = double.Parse(textBox9.Text);
            kertoja10 = double.Parse(textBox10.Text);
            kertoja11 = double.Parse(textBox12.Text);
            kertoja12 = double.Parse(textBox13.Text);



            if (checkBox1.Checked)
            {
                Pepperoni = double.Parse(checkBox1.Text); richtxtbox.Text += kertoja1 + "Pepperoni Pizza" + "\n\n"; //kerrotaan missä pepperoni pitsa sijaitsee ja kerrotaan minne se laitetaan ja tehdään rivinvaihto

            }


            if (checkBox2.Checked)
            {
                hawai = double.Parse(checkBox2.Text); richtxtbox.Text += kertoja2 + "Hawai pizza" + "\n\n";
            }


            if (checkBox3.Checked)
            {
                jauhenliha = double.Parse(checkBox3.Text); richtxtbox.Text += kertoja3 + "Jauhenliha Pizza" + "\n\n";
            }


            if (checkBox4.Checked)
            {
                lihamestari = double.Parse(checkBox4.Text); richtxtbox.Text += kertoja4 + "Lihamestari Pizza" + "\n\n";
            }


            if (checkBox5.Checked)
            {
                texas = double.Parse(checkBox5.Text); richtxtbox.Text += kertoja5 + "Texas Monster Pizza" + "\n\n";
            }


            if (checkBox6.Checked)
            {
                kasvis = double.Parse(checkBox6.Text); richtxtbox.Text += kertoja6 + "kasvis Pizza" + "\n\n";
            }


            if (checkBox7.Checked)
            {
                vege = double.Parse(checkBox7.Text); richtxtbox.Text += kertoja7 + "Vege Pizza" + "\n\n";
            }


            if (checkBox8.Checked)
            {
                kebabsalami = double.Parse(checkBox8.Text); richtxtbox.Text += kertoja8 + "Kebabsalami Pizza" + "\n\n"; //kerrotaan missä kebabsalami sijaitsee ja minne tulostetaan vastaus ja tulostetaan pizzan nimi ja tehdään rivin vaihto
            }


            if (checkBox9.Checked)
            {
                kanabbq = double.Parse(checkBox9.Text); richtxtbox.Text += kertoja9 + "Kanabbq Pizza" + "\n\n";
            }


            if (checkBox10.Checked)
            {
                kebabmajoneesi = double.Parse(checkBox9.Text); richtxtbox.Text += kertoja10 + "kebabmajoneesi Pizza" + "\n\n";
            }
            if (chcjuoma1.Checked)
            {
                juoma1 = double.Parse(chcjuoma1.Text); richtxtbox.Text += kertoja11 + "0.5l " + "\n\n";
            }
            if (chcjuoma2.Checked)
            {
                juoma2 = double.Parse(chcjuoma2.Text); richtxtbox.Text += kertoja12 + "0.5l " + "\n\n";
            }


            tulos = Pepperoni * kertoja1 + hawai * kertoja2 + jauhenliha * kertoja3 + lihamestari * kertoja3 + texas * kertoja3 + kasvis * kertoja3 + kebabsalami * kertoja3 + kebabsalami * kertoja4 + kanabbq * kertoja9 + kebabmajoneesi * kertoja10 + juoma1 * kertoja11 + juoma2 * kertoja12;
            //Tässä kerrotaan missä summa on ja Pizzat kertaa niiden hinnat sillä määrällä monta niitä on
            textBox11.Text = tulos.ToString();//tulostetaan pizzojen määrä ja hinta textboxiin
        } catch (Exception ex)
            {
                MessageBox.Show("OLET TEHNYT TÄMÄ VÄÄRIN!?! LAITA JOKAISEEN TEKSTIBOXIIN JOTAIN!?!");

            }
            



        }
        
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnnollaa_Click(object sender, EventArgs e)
        {
            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
