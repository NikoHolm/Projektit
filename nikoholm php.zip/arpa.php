<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arpajaiset</title>
</head>
<body>
    <h1>
        Kiitos osallistumisesta arpajaisiin toivottavasti onni on sinun puolellasi ja voitatte pääpalkinnon
    </h1>
    <?php
    $nimi = $_POST["nimi"]; //luodaan muuttujat
    $sposti = $_POST["sposti"];
    $numero = $_POST["numero"];
echo "Hei ". $nimi; //tulostetaan nimi
echo "<br>"; //pidetään tauko
echo "Olette osallistunut arpajaisiin";
echo "<br>";
echo "Lähetämme tarkemmat tiedot sähköpostiinne ".  $sposti;
echo "<br>";
echo "Ilmoitamme myös viestillä kun sähköposti on lähetetty tähän numeroon ". $numero;
echo "<br>";
echo(rand(1,10000)); //tässä määritellään minimi ja maximi numero mistä kone arpoo numeron
echo "<br>";
    ?>
    <a href="/html/html/arpajaiset.html">Paluu nappi</a> <!--paluunappi-->
</body>
</html>