<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$radioVal = $_POST["MyRadio"];

if($radioVal == "yksi") //tarkastetaan onko checkbox merkitty 
{
    echo("1*1 = 1 , 1*2 = 2, 3*1 = 3, 4*1 = 4, 5*1 = 5, 6*1 = 6, 7*1 = 7, 8*1 = 8, 9*1 = 9, 10*1 = 10");
} //tulostetaan vastaus
else if ($radioVal == "kaksi")
{
    echo("2*1 = 1,  2*2= 4, 2*3 = 6,  2*4 = 8, 2*5 = 10, 2*6 = 12, 2*7 = 14, 2*8 = 16, 2*9 = 18, 2*10 = 20");
}
if($radioVal == "kolme")
{
    echo("1 x 3 = 3; 2 x 3 = 6; 3 x 3 = 9; 4 x 3 = 12; 5 x 3 = 15; 6 x 3 = 18; 7 x 3 = 21; 8 x 3 = 24; 9 x 3 27; 10 x 3 = 30");
}
else if ($radioVal == "neljä")
{
    echo("1 x 4 = 4; 2 x 4 = 8 4x3 = 16 4x5 = 20 4x6 = 24 4x7 = 28 4x8 = 32 4x9 = 36 4x10 = 40");
}
if($radioVal == "viisi")
{
    echo("5x1 = 5 5x2 = 10 5x3 = 15 5x4 = 20 5x5 = 25 5x6 = 30 5x7 = 35 = 5x8 = 40 5x9 = 45 5x10 = 50");
}
else if ($radioVal == "kuusi")
{
    echo("6 * 1 = 6 6x2 = 12 6 x 3 = 24 6*5 = 30 6x6 = 36 6x7 = 42 6x8 48 6x9 = 54 6x10 = 60");
}
if($radioVal == "seiska")
{
    echo("7 x 1 = 7; 7 x 2 = 14 7x3 = 21 7x4 = 28 7x5 = 35 7x6 = 42 7x7= 49 7x8 = 56 7x9 = 63 7x10 = 70");
}
else if ($radioVal == "kasi")
{
    echo("1 x 8 = 2 x 8 = 3 x 8 = 4 x 8 = 5 x 8 = 6 x 8 = 7 x 8 = 56 8 x 8 = 64 9 x 8 = 72 8 x 10 = 80");
}
if($radioVal == "ysi")
{
    echo("09, 18, 27, 36, 45, 54, 63, 81,90");
}
else if ($radioVal == "kymppi")
{
    echo("1 x 10 = 10; 2*10 20; 3*10 = 30 yms yms");
}
echo "<br>";
?><a href="/html/html/kerto.html">Paluu nappi</a> <!--paluunappi-->
</body>
</html>