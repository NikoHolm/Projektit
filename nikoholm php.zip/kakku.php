<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kakkuja</title>
</head>
<body>
    <?php
    $normaali = $_POST['normaali']; //luodaan muuttujat
    $tupla = $_POST['tupla'];
    $puoli = $_POST['puolikas'];
    $kakku = $_POST['kakku'];
    if($kakku == "normaali") //checkataan onko tämä juuri valittu
{
    echo("1. litra jauhoja, 3 munaa, puoli litraa maitoa, desi sokeria, 100 g rasvaa, puoli teelusikallista suolaa, 2 teelusikallista hiivaa");
}
else if ($kakku == "tupla")
{
    echo("2. litra jauhoja, 6 munaa, 1 litra maitoa, kaksi desi sokeria, 200 g rasvaa, teelusikallinen suolaa, 4 teelusikallista hiivaa");
}
if($kakku == "puolikas")
{
    echo("puoli litra jauhoja, 1.5 munaa, 1/4 litra maitoa, puoli desi sokeria, 50 g rasvaa, 1/4 teelusikallista suolaa, 1 teelusikallista hiivaa");
}
    ?>
    <h1> Tähän voit kirjoittaa reseptisi</h1>
    <textarea id="w3review" name="w3review" rows="4" cols="50"></textarea> <!--tässä teemme isomman textboxin jota voi paremmin säädellä isontaa ja pienentää-->
</body>
</html>