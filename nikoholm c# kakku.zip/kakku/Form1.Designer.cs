﻿namespace kakku
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.txtkakku = new System.Windows.Forms.TextBox();
            this.btn = new System.Windows.Forms.Button();
            this.txtainesosat = new System.Windows.Forms.RichTextBox();
            this.txtresepti = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(44, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "kakkukpl";
            // 
            // txtkakku
            // 
            this.txtkakku.Location = new System.Drawing.Point(105, 119);
            this.txtkakku.Name = "txtkakku";
            this.txtkakku.Size = new System.Drawing.Size(50, 20);
            this.txtkakku.TabIndex = 9;
            this.txtkakku.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // btn
            // 
            this.btn.Location = new System.Drawing.Point(105, 145);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(75, 23);
            this.btn.TabIndex = 10;
            this.btn.Text = "OK";
            this.btn.UseVisualStyleBackColor = true;
            this.btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtainesosat
            // 
            this.txtainesosat.Location = new System.Drawing.Point(267, 45);
            this.txtainesosat.Name = "txtainesosat";
            this.txtainesosat.Size = new System.Drawing.Size(149, 198);
            this.txtainesosat.TabIndex = 12;
            this.txtainesosat.Text = "";
            // 
            // txtresepti
            // 
            this.txtresepti.Location = new System.Drawing.Point(456, 45);
            this.txtresepti.Name = "txtresepti";
            this.txtresepti.Size = new System.Drawing.Size(164, 198);
            this.txtresepti.TabIndex = 13;
            this.txtresepti.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtresepti);
            this.Controls.Add(this.txtainesosat);
            this.Controls.Add(this.btn);
            this.Controls.Add(this.txtkakku);
            this.Controls.Add(this.label5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtkakku;
        private System.Windows.Forms.Button btn;
        private System.Windows.Forms.RichTextBox txtainesosat;
        private System.Windows.Forms.RichTextBox txtresepti;
    }
}

