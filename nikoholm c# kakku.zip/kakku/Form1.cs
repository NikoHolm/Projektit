﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kakku
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double munia = 0;
            double sokeria = 0;
            double jauhoja = 0;
            double leivinjauho = 0;
            double kakkukpl = 0;

            kakkukpl = double.Parse(txtkakku.Text);
            munia = 6 * kakkukpl;
            sokeria = 1.5 * kakkukpl;
            jauhoja = 1.5 * kakkukpl;
            leivinjauho = 1.5 * kakkukpl;
            //tulostus tekstikenttään eri riveille.
            txtainesosat.Text = "tarvittavat ainesosat";
            txtainesosat.Text += Environment.NewLine + "munia " + munia;
            txtainesosat.Text += Environment.NewLine + "sokeria dl " + jauhoja;
            txtainesosat.Text += Environment.NewLine + "jauhoja dl" + jauhoja;
            txtainesosat.Text += Environment.NewLine + " leivinjauhoja tl " + leivinjauho;

            txtresepti.Text = "ohje";
            txtresepti.Text += Environment.NewLine + "1. Vatkaa sokeri ja munat vaahdoksi. ";
            txtresepti.Text += Environment.NewLine + "2. Sekoita jauhot ja leivinjauhe. ";
            txtresepti.Text += Environment.NewLine + "3. Sekoita muna-sokerivaahto ja jauhoseos. ";
            txtresepti.Text += Environment.NewLine + " 4. Paista 45 min 175°C lämpötilassa.";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
